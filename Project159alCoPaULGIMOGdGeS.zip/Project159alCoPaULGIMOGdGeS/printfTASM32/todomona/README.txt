and here's the oldschool assembler for the bonus.

~alCoPaUL [GIMO][As][aBrA][NPA][b8][BCVG][rRlf] 2/1/2023 NYC