Use NASM (Netwide Assembler) version 2.08(RCs) to assemble the SnowLeopard Quines.

~alCoPaUL [GIMO][As][aBrA][NPA][b8][BCVG][rRlf] 2/1/2023 NYC