Visual Studio 2010 C/C++ runtimes are required.

~alCoPaUL [GIMO][As][aBrA][NPA][b8][BCVG][rRlf] 2/1/2023 NYC