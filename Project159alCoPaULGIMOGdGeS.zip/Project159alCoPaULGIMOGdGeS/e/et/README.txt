Use The Visual Studio 2010 build tools coz the .lib files are from there.

~alCoPaUL [GIMO][As][aBrA][NPA][b8][BCVG][rRlf] 2/1/2023 NYC