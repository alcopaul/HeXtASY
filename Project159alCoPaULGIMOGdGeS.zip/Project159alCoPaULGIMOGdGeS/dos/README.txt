Run on DOSBox 0.74-3 for the ideal results..

~alCoPaUL [GIMO][As][aBrA][NPA][b8][BCVG][rRlf] 2/1/2023 NYC